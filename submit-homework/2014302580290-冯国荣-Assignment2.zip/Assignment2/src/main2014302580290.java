import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;



public class main2014302580290 {

	public static void main(String[] args) throws IOException {
		
		// TODO �Զ����ɵķ������
		
File input = new File("teacher.html");

Document doc = Jsoup.parse(input, "UTF-8","http://staff.whu.edu.cn/show.jsp?lang=cn&n=Xiaoqing Liu/");
String title = doc.title();
Elements name = doc.select("h3[class=title]");
System.out.println(name.text());
String Name=name.text();
Elements a = doc.select("div[class=details col-md-10 col-sm-9 col-xs-7]");
//System.out.println(a.text());
String nei=a.text();
Elements j = doc.select("div[class=details col-md-12 col-sm-12 col-xs-12]");
System.out.println(j.text());
String[] strarray=nei.split(" "); 
for (int i = 4; i < 6; i++) 
   System.out.println(strarray[i]);

/*StringBuffer sb = new StringBuffer();
for(int i = 0; i < strarray.length; i++){
sb. append(strarray[i]);
String newStr = sb.toString();

}
System.out.println(sb);
*/
FileWriter fileWriter=new FileWriter("Teacher.txt");
fileWriter.write("������"+Name+"\r\n");
fileWriter.write(strarray[1]);
fileWriter.write(strarray[2]);
fileWriter.write(strarray[3]+"\r\n");
fileWriter.write(strarray[4]+"\r\n");
fileWriter.write(strarray[5]+"\r\n");
Pattern pat1=null;
String rex1 = "[0-9]+-+[0-9]{8}";
pat1 = Pattern.compile(rex1);
Matcher mat1 = pat1.matcher(nei);
while(mat1.find()){
	fileWriter.write("��ϵ�绰��"+mat1.group()+"\r\n");
}
Pattern pat2=null;
String rex2 = "[\\w[.-]]+@[\\w[.-]]+\\.[\\w]+";
pat2 = Pattern.compile(rex2);
Matcher mat2 = pat2.matcher(nei);
while(mat2.find()){
	fileWriter.write("���䣺"+mat2.group()+"\r\n");
}
fileWriter.write(j.text());
//Elements phone = a.select("p:matchesOwn(^\\d{3}-\\d{8}$)");
//System.out.println(phone.text());
/*ReadWriteFile2014302580290.creatTxtFile();
ReadWriteFile2014302580290.readTxtFile();
fileWriter.write("������"+Name+"\n");
fileWriter.write(strarray[2]+"\n");
fileWriter.write(strarray[3]+"\n");
fileWriter.write(strarray[4]+"\n");
fileWriter.write(strarray[5]+"\n");
fileWriter.write(strarray[6]);
fileWriter.write(mat1.group()+"\n");
fileWriter.write(strarray[7]);
fileWriter.write(mat2.group()+"\n");
fileWriter.write(j.text());*/



fileWriter.flush();
fileWriter.close();

}
	
                                                            
}
	
